''' Reemplazar la instrucción while por for 
i = 0
while i < 50:
    print("Iteración {}".format(i + 1))
    i +=1
'''

for i in range( 0 , 51 ):
    print("for Iteración {}".format(i + 1))
    i +=1