n = int(input("Ingrese un número para comenzar la cuenta de impares\n"))
impares = 1
while impares <= n:
    print(impares)
    impares = impares + 2