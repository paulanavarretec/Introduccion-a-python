n = int(input("Ingrese un número para comenzar la cuenta de pares\n"))
pares = 2
while pares <= n:
    print(pares)
    pares = pares + 2