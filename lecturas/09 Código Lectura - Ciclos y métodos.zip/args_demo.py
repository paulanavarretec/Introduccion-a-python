#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys

print("This is the name of the script: {}".format(sys.argv[0]))
print("Number of arguments: ", len(sys.argv))
print("Arguments: ", str(sys.argv))
